#ifndef HOME_H
#define HOME_H

#include <iostream>
#include <string>
#include <cstdlib>
#include <cctype>

class Home {

 public:

    void get_name(){std::cin >> name;}

    void virtual output(std::ostream& outs) {};

    void virtual input(std::istream& ins) {};


 protected:
    std::string name;
};
//**************************************************************
class Troll_Home : public Home {

 public:
    //Troll();

    void output(std::ostream& outs);

    void input(std::istream& ins);


 private:
    bool snow;
    double depth;
    double height;
    int rocks;
};
//***************************************************************
class Dog_Home : public Home {

 public:
    //Dog();

    void output(std::ostream& outs);

    void input(std::istream& ins);


 private:
    std::string color;
    std::string dog_type;
    int y;
    int x;
    bool toys;
};
//****************************************************************
class Harpies_Home : public Home {

 public:
    //Harpies();

    void output(std::ostream& outs);

    void input(std::istream& ins);


 private:
    std::string wood_type;
    int height_in_tree;
    int baby_harpies;
};
//****************************************************************
class Dragon_Home : public Home {

 public:
    //Dragon();

    void output(std::ostream& outs);

    void input(std::istream& ins);


 private:
    std::string size_of_dragon;
    double height;
    double depth;
    bool dead_stuff; //bones,blood,etc
};
//*****************************************************************
class Centaur_Home : public Home {

 public:
    //Centaur();

    void output(std::ostream& outs);

    void input(std::istream& ins);

 private:
    bool flowers;
    std::string forest;
    bool farrier;
    bool fairies;
};
//*****************************************************************
#endif // HOME_H





