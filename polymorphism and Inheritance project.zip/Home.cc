#include "Home.h"


using namespace std;

void Centaur_Home::output(ostream& outs)
{
  if(&outs == &cout)
  {
    cout << "Hello my name is " << name << " welcome to my home\n";
    cout << "The size of the forest is: " << forest << endl;
    if(flowers)
    {
        cout << "The smell of nature is sure pleasant\n";
    }
    else
    {
        cout << "I must grow some flowers to support my home\n";
    }
    if(farrier)
    {
        cout << "I am thankful for my smooth hooves\n";
    }
    else
    {
        cout << "Rough hooves for daysssss \n";
    }
    if(fairies)
    {
        cout << "Fairies make this place beautiful\n";
    }
    else
    {
        cout << "All is lost in this forest :/ \n";
    }
  }
  else
  {
    outs << 5 << endl;
    outs << name << endl;
    outs << forest << endl;
    outs << flowers << endl;
    outs << farrier << endl;
    outs << fairies << endl;
  }
}
void Centaur_Home::input(istream& ins)
{
    if(&ins == &cin)
    {
        cout << "What is the creature's name?\n";
        get_name();
        cout << "What is the size of this forest(small,medium,large)\n";
        cin >> forest;
        if(forest == "large")
        {
            cout << "This forest is blooming with life and nature magic\n";
        }
        else if(forest == "medium")
        {
            cout << "This forest must be protected in order to grow stronger\n";
        }
        else
        {
            cout << "The forest's magical presence is very weak\n";
        }
	cout << "Is there a lot of flowers in the forest?\n";
        char answer;
	cin >> answer;
        if(answer == 'y'||'Y' == answer)
        {
            flowers = true;
        }
        else
        {
            flowers = false;
        }
        cout << "Do I have a personal farrier?\n";
        char choice;
	cin >> choice;
        if(choice == 'y'||'Y' == choice)
        {
             farrier = true;
        }
        else
        {
             farrier = false;
        }
        cout << "Is there fairies in the forest?\n";
        char option;
	cin >> option;
        if(option == 'y'||'Y' == option)
        {
            fairies = true;
        }
        else
        {
            fairies = false;
        }
    }
    else
    {
   	get_name();
	ins >> forest;
	ins >> flowers;
	ins >> farrier;
	ins >> fairies;
    }
}
//*************************************************
void Dog_Home::output(ostream& outs)
{ if(&outs == &cout)
  {
    cout << "The dogs name is " << name << endl;
    cout << "The color of the dog house is " << color << endl;
    cout << "The dog breed is " << dog_type << endl;
    cout << "The dimensions of the house are " << x << " by " << y << endl;
    if(toys)
    {
        cout << "The dog will love these toys thanks Mr.D!!\n";
    }
    else
    {
        cout << "Sad little puppy today :( \n";
    }
  }
  else
  {
    outs << 2 << endl;
    outs << name << endl;
    outs << color << endl;
    outs << dog_type << endl;
    outs << x << y << endl;
    outs << toys << endl;
  }
}
void Dog_Home::input(istream& ins)
{
    if(&ins == &cin)
    {
        cout << "What is the name of the creature\n";
        get_name();
        cout << "What color is the dog's house?\n";
        cin >> color;
        cout << "What breed of dog is the dog?\n";
        cin >> dog_type;
        cout << "What are the dimensions of the house?\n";
        cin >> x >> y;
        cout << "Are there toys present in this house?\n";
        char answer;
	cin >> answer;
        if(answer == 'y'||'Y' == answer)
        {
            toys = true;
        }
        else
        {
            toys = false;
        }
    }
    else
    {
        get_name();
        ins >> color;
        ins >> dog_type;
        ins >> x >> y;
        ins >> toys;
    }
}
//******************************************************************************************
void Dragon_Home::output(ostream& outs)
{ if(outs == cout)
  {
    cout << name << " the fire breathing dragon " << endl;
    cout << "The size of the dragon is " << size_of_dragon << endl;
    cout << "The size of the house is " << depth << " by: " << height << endl;
    if(dead_stuff)
    {
        cout << "RIP who ever messed with this dragon.\n";
    }
    else
    {
        cout << "The dragon is just wants to sleep for now....\n";
    }
  }
  else
  {
    outs << 4 << endl;
    outs << name << endl;
    outs << size_of_dragon << endl;
    outs <<  depth << height << endl;
    outs << dead_stuff;
  }
}
void Dragon_Home::input(istream& ins)
{
    if(&ins == &cin)
    {
        cout << "What is this creature's name?\n";
        get_name();
        cout << "How big is this dragon?(small,medium,large)\n";
        cin >> size_of_dragon;
        if(size_of_dragon == "large")
        {
            cout << "You will need a large cave so enter values 20 or above for depth and height\n";
            cin >> depth >> height;
        }
        else if(size_of_dragon == "medium")
        {
            cout << "You will need a decent size cave to contain this dragon enter a value greater then 5 for both\n";
            cin >> depth >> height;
        }
        else
        {
            cout << "You will need a small cave at least for this dragon enter a value greater then 0 for both\n";
            cin >> depth >> height;
        }
        cout << "Is there dead stuff in the house?(Y or N)\n";
        char answer;
        cin >> answer;
        if(answer == 'y'||'Y' == answer)
        {
            dead_stuff = true;
        }
        else
        {
            dead_stuff = false;
        }
    }
    else
    {
        get_name();
        ins >> size_of_dragon;
        ins >> depth >> height;
       	ins >> dead_stuff;
    }
}
//*******************************************************************************************
void Harpies_Home::output(ostream& outs)
{
  if(&outs == &cout)
  {
    cout << "My name is " << name <<" and I am a harpy" << endl;
    cout << "The type of wood the nest is made out of is " << wood_type << endl;
    cout << "The nest is located " << height_in_tree <<" feet in the tree\n";
    cout << "There are " << baby_harpies <<" baby harpies in the nest\n";
  }
  else
  { outs<< 3 <<endl;
    outs <<  name << endl;
    outs <<wood_type << endl;
    outs << height_in_tree << endl;
    outs <<  baby_harpies<<endl;
  }
}
void Harpies_Home::input(istream& ins)
{
    if(&ins == &cin)
    {
        cout << "What is the creature's name?\n";
        get_name();
        cout << "What type of wood is the nest made out of:\n";
        cin >> wood_type;
        cout << "How high in the tree is the nest(in feet):\n";
        cin >> height_in_tree;
        cout << "How many baby harpies are in the nest:\n";
        cin >> baby_harpies;
    }
    else
    {
        get_name();
        ins >> wood_type;
        ins >> height_in_tree;
        ins >> baby_harpies;
    }
}
//**************************************************************************************************
void Troll_Home::output(ostream& outs)
{
  if(&outs == &cout)
  {
	cout << "This is " << name << " the Troll " << endl;
   	cout << "The size of the house in depth and height is:" << depth << " by " << height << endl;
	if(snow)
	{ cout << "The house has snow." << endl;}
	else
	{ cout << "The house does not have snow" << endl;
      cout << "NO FLUFFY STUFF TO PLAY WITH\n";
	}
	cout << "There are " << rocks << "rocks in the home\n";
	cout << "ROCKKKKKKKKKKK SMASH or NO ROCK SMASH BUT ROCK SOUP \n";
  }
  else
  {
    outs << 1 << endl;
    outs << name << endl;
    outs << depth << height << endl;
    outs << snow << endl;
    outs << rocks << endl;
  }
}
void Troll_Home::input(istream& ins)
{
 if(&ins == &cin)
  {
    cout << "What is the creatures name\n";
    get_name();
    cout << endl;
    cout << "What is the size of the home(depth and height)\n";
    cin >> depth >> height;
    cout << "Does this house have snow?(Y or N)\n";
    char answer;
    cin >> answer;
    if(answer == 'y'||'Y' == answer)
    {
 	snow = true;
    }
    else
    {
	snow = false;
    }
    cout << "How many rocks are currently located in the Home\n";
    cin >> rocks;
  }
  else{
    get_name();
    ins >> depth >> height;
    ins >> snow;
    ins >> rocks;
  }
}





