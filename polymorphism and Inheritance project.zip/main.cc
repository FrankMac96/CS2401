#include <iostream>
#include <string>
#include <fstream>
#include <list>
#include <cstdlib>
#include "Home.h"

using namespace std;
int menu();
int main()
{
    list<Home*> Frank;
    list<Home*>::iterator it;

    int type;
    ifstream fin;
    fin.open("savefile");
     if(fin.fail())
     {
         cout << "file failed to open enter another file.\n";
         type = 0;
     }

     fin>>type;

    while(type != 0)
    {
      switch(type)
      {
        case(1):
        {
         Troll_Home* tmp;
	 tmp = new Troll_Home;
         tmp->input(fin);
         Frank.push_front(tmp);
         break;
        }
        case(2):
        {
         Dog_Home* temp;
	 temp = new Dog_Home;
         temp->input(fin);
         Frank.push_front(temp);
         break;
        }
        case(3):
        {
         Harpies_Home* ptr;
	 ptr = new Harpies_Home;
         ptr->input(fin);
         Frank.push_front(ptr);
         break;
        }
        case(4):
        {
         Dragon_Home* animal;
         animal = new Dragon_Home;
         animal->input(fin);
         Frank.push_front(animal);
         break;
        }
        case(5):
        {
         Centaur_Home* horns;
         horns = new Centaur_Home;
         horns->input(fin);
         Frank.push_front(horns);
         break;
        }
        case(6):
        {
            for(it=Frank.begin(); it != Frank.end(); it++)
            {
                (*it)->output(cout);
            }
         break;
        }
      }
    fin >> type;
    }
    int choice = menu();
    while(choice != 0)
    {
      switch(choice)
      {
        case(1):
        {
         Troll_Home* tmp;
	 tmp = new Troll_Home;
         tmp->input(cin);
         Frank.push_front(tmp);
         break;
        }
        case(2):
        {
         Dog_Home* temp;
	 temp = new Dog_Home;
         temp->input(cin);
         Frank.push_front(temp);
         break;
        }
        case(3):
        {
         Harpies_Home* ptr;
	 ptr = new Harpies_Home;
         ptr->input(cin);
         Frank.push_front(ptr);
         break;
        }
        case(4):
        {
         Dragon_Home* animal;
	 animal = new Dragon_Home;
         animal->input(cin);
         Frank.push_front(animal);
         break;
        }
        case(5):
        {
         Centaur_Home* horns;
         horns = new Centaur_Home;
         horns->input(cin);
         Frank.push_front(horns);
         break;
        }
        case(6):
        {
            for(it=Frank.begin(); it != Frank.end(); it++)
            {
                (*it)->output(cout);
		cout << "**********************************" << endl;
            }
	break;
        }
      }
        choice=menu();
    }
 ofstream fout;
 fout.open("savefile");
 for(it = Frank.begin(); it != Frank.end(); it++)
 {
  	(*it)->output(fout);
 }
 fout << 0 << endl;
 fin.close();
 return 0;
}
int menu()
{  
    int choice;
    cout << "1.) Troll Home\n";
    cout << "2.) Dog Home\n";
    cout << "3.) Harpies Home\n";
    cout << "4.) Dragon Home\n";
    cout << "5.) Centaur Home\n";
    cout << "6.) Display\n";
    cout << "0.) Exit\n";
   
    cin >> choice;
    return choice;
}
